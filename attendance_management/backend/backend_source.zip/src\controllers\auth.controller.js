const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const pool = require('../config/database');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');
const { sendSuccess } = require('../utils/apiResponse');

const login = asyncHandler(async (req, res) => {
  const email = String(req.body.email || '')
    .trim()
    .toLowerCase();

  const password = String(req.body.password || '');

  if (!email || !password) {
    throw new AppError(
      422,
      'VALIDATION_ERROR',
      'Email and password are required',
    );
  }

  const [rows] = await pool.execute(
    `
      SELECT
        u.id AS user_id,
        u.email,
        u.password_hash,
        u.role,
        u.status AS user_status,

        e.id AS employee_id,
        e.employee_code,
        e.full_name,
        e.phone,
        e.profile_image_url,
        e.company_id,
        e.branch_id,
        e.department_id,
        e.designation_id,
        e.employment_status,

        c.name AS company_name,
        c.timezone,

        b.name AS branch_name,
        d.name AS department_name,
        des.name AS designation_name

      FROM users u

      INNER JOIN employees e
        ON e.user_id = u.id

      INNER JOIN companies c
        ON c.id = e.company_id

      INNER JOIN branches b
        ON b.id = e.branch_id

      LEFT JOIN departments d
        ON d.id = e.department_id

      LEFT JOIN designations des
        ON des.id = e.designation_id

      WHERE LOWER(u.email) = LOWER(?)

      LIMIT 1
    `,
    [email],
  );

  const account = rows[0];

  if (!account) {
    throw new AppError(
      401,
      'INVALID_CREDENTIALS',
      'Invalid email address or password',
    );
  }

  if (
    account.user_status !== 'active' ||
    account.employment_status !== 'active'
  ) {
    throw new AppError(
      403,
      'EMPLOYEE_INACTIVE',
      'This employee account is not active',
    );
  }

  const passwordMatches = await bcrypt.compare(
    password,
    account.password_hash,
  );

  if (!passwordMatches) {
    throw new AppError(
      401,
      'INVALID_CREDENTIALS',
      'Invalid email address or password',
    );
  }

  const accessToken = jwt.sign(
    {
      userId: account.user_id,
      employeeId: account.employee_id,
      companyId: account.company_id,
      branchId: account.branch_id,
      role: account.role,
    },
    process.env.JWT_ACCESS_SECRET,
    {
      expiresIn:
        process.env.JWT_ACCESS_EXPIRES_IN || '1h',
    },
  );

  await pool.execute(
    `
      UPDATE users
      SET last_login_at = UTC_TIMESTAMP()
      WHERE id = ?
    `,
    [account.user_id],
  );

  return sendSuccess(res, {
    message: 'Login successful',
    data: {
      access_token: accessToken,
      token_type: 'Bearer',
      expires_in:
        process.env.JWT_ACCESS_EXPIRES_IN || '1h',

      user: {
        user_id: account.user_id,
        employee_id: account.employee_id,
        employee_code: account.employee_code,
        role: account.role,

        name: account.full_name,
        email: account.email,
        phone: account.phone,
        profile_image_url: account.profile_image_url,

        company_id: account.company_id,
        company_name: account.company_name,

        branch_id: account.branch_id,
        branch_name: account.branch_name,

        department_id: account.department_id,
        department_name: account.department_name,

        designation_id: account.designation_id,
        designation_name: account.designation_name,

        timezone: account.timezone,
      },
    },
  });
});

const getCurrentUser = asyncHandler(async (req, res) => {
  const [rows] = await pool.execute(
    `
      SELECT
        u.id AS user_id,
        u.email,
        u.role,

        e.id AS employee_id,
        e.employee_code,
        e.full_name,
        e.phone,
        e.profile_image_url,
        e.date_of_joining,

        c.id AS company_id,
        c.name AS company_name,

        b.id AS branch_id,
        b.name AS branch_name,

        d.id AS department_id,
        d.name AS department_name,

        des.id AS designation_id,
        des.name AS designation_name

      FROM users u

      INNER JOIN employees e
        ON e.user_id = u.id

      INNER JOIN companies c
        ON c.id = e.company_id

      INNER JOIN branches b
        ON b.id = e.branch_id

      LEFT JOIN departments d
        ON d.id = e.department_id

      LEFT JOIN designations des
        ON des.id = e.designation_id

      WHERE u.id = ?
        AND e.id = ?

      LIMIT 1
    `,
    [
      req.auth.userId,
      req.auth.employeeId,
    ],
  );

  if (!rows[0]) {
    throw new AppError(
      404,
      'EMPLOYEE_NOT_FOUND',
      'Employee profile was not found',
    );
  }

  return sendSuccess(res, {
    message: 'Employee profile fetched successfully',
    data: rows[0],
  });
});

module.exports = {
  login,
  getCurrentUser,
};