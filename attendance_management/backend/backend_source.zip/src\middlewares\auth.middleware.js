const jwt = require('jsonwebtoken');

const AppError = require('../utils/AppError');

const authenticate = (req, res, next) => {
  const authorization = req.headers.authorization;

  if (
    !authorization ||
    !authorization.startsWith('Bearer ')
  ) {
    return next(
      new AppError(
        401,
        'UNAUTHORIZED',
        'Authentication token is required',
      ),
    );
  }

  const token = authorization.substring(7);

  try {
    req.auth = jwt.verify(
      token,
      process.env.JWT_ACCESS_SECRET,
    );

    return next();
  } catch (error) {
    return next(
      new AppError(
        401,
        'TOKEN_INVALID',
        'Authentication token is invalid or expired',
      ),
    );
  }
};

module.exports = {
  authenticate,
};