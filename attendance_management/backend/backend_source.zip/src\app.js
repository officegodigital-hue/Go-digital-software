const express = require('express');
const cors = require('cors');
const helmet = require('helmet');

const pool = require('./config/database');

const authRoutes = require('./routes/auth.routes');

const attendanceRoutes = require(
  './routes/attendance.routes',
);

const attendanceHistoryRoutes = require(
  './routes/attendanceHistory.routes',
);
const leaveRoutes = require(
  './routes/leave.routes',
);

const {
  notFoundHandler,
  errorHandler,
} = require('./middlewares/error.middleware');

const app = express();

/**
 * Hide Express information from response headers.
 */
app.disable('x-powered-by');

/**
 * Add basic security headers.
 */
app.use(helmet());

/**
 * Allow Flutter Web and other approved clients
 * to access the backend.
 */
app.use(
  cors({
    origin: true,
    credentials: true,

    methods: [
      'GET',
      'POST',
      'PUT',
      'PATCH',
      'DELETE',
      'OPTIONS',
    ],

    allowedHeaders: [
      'Content-Type',
      'Authorization',
    ],
  }),
);

/**
 * Parse JSON request bodies.
 */
app.use(
  express.json({
    limit: '2mb',
  }),
);

/**
 * Parse URL-encoded request bodies.
 */
app.use(
  express.urlencoded({
    extended: true,
    limit: '2mb',
  }),
);

/**
 * Backend health endpoint.
 *
 * GET http://localhost:3000/health
 */
app.get('/health', (req, res) => {
  return res.status(200).json({
    success: true,
    message: 'Attendance API is running',
    timestamp: new Date().toISOString(),
  });
});

/**
 * MySQL database health endpoint.
 *
 * GET http://localhost:3000/db-health
 */
app.get(
  '/db-health',
  async (req, res, next) => {
    try {
      const [rows] = await pool.execute(
        `
          SELECT
            DATABASE() AS database_name,
            NOW() AS database_time
        `,
      );

      return res.status(200).json({
        success: true,
        message:
          'MySQL database connected successfully',

        data: {
          database:
            rows[0]?.database_name || null,

          database_time:
            rows[0]?.database_time || null,
        },
      });
    } catch (error) {
      return next(error);
    }
  },
);

/**
 * Authentication routes.
 *
 * POST /api/v1/auth/login
 */
app.use(
  '/api/v1/auth',
  authRoutes,
);

/**
 * Current-day attendance routes.
 *
 * GET  /api/v1/attendance/today
 * POST /api/v1/attendance/check-in
 * POST /api/v1/attendance/check-out
 * POST /api/v1/attendance/breaks/start
 * POST /api/v1/attendance/breaks/end
 */
app.use(
  '/api/v1/attendance',
  attendanceRoutes,
);

/**
 * Attendance history routes.
 *
 * GET /api/v1/attendance/history
 * GET /api/v1/attendance/history?month=2026-07
 */
app.use(
  '/api/v1/attendance',
  attendanceHistoryRoutes,
);



app.use(
  '/api/v1/leaves',
  leaveRoutes,
);

/**
 * These error middleware functions must remain
 * after all API routes.
 */
app.use(notFoundHandler);
app.use(errorHandler);

module.exports = app;