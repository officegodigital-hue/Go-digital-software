const notFoundHandler = (req, res) => {
  return res.status(404).json({
    success: false,
    message: 'API endpoint not found',
    error: {
      code: 'ROUTE_NOT_FOUND',
      details: null,
    },
  });
};

const errorHandler = (error, req, res, next) => {
  console.error(error);

  const statusCode = error.statusCode || 500;
  const code = error.code || 'SERVER_ERROR';

  const message = error.isOperational
    ? error.message
    : 'An unexpected server error occurred';

  return res.status(statusCode).json({
    success: false,
    message,
    error: {
      code,
      details: error.details || null,
    },
  });
};

module.exports = {
  notFoundHandler,
  errorHandler,
};