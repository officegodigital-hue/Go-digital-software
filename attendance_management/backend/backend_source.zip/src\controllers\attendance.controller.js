const asyncHandler = require('../utils/asyncHandler');
const { sendSuccess } = require('../utils/apiResponse');

const attendanceService = require(
  '../services/attendance.service',
);

/**
 * GET /api/v1/attendance/today
 *
 * Returns the logged-in employee's attendance status
 * for the current company-local date.
 */
const getToday = asyncHandler(async (req, res) => {
  const data =
    await attendanceService.getTodayAttendance({
      employeeId: req.auth.employeeId,
    });

  return sendSuccess(res, {
    statusCode: 200,
    message:
      'Today attendance fetched successfully',
    data,
  });
});

/**
 * POST /api/v1/attendance/check-in
 *
 * Optional body:
 * {
 *   "location": {
 *     "latitude": 12.921456,
 *     "longitude": 80.127845,
 *     "accuracy_meters": 10,
 *     "is_mocked": false
 *   }
 * }
 */
const checkIn = asyncHandler(async (req, res) => {
  const data = await attendanceService.checkIn({
    employeeId: req.auth.employeeId,
    body: req.body || {},
  });

  return sendSuccess(res, {
    statusCode: 200,
    message: 'Check-in successful',
    data,
  });
});

/**
 * POST /api/v1/attendance/check-out
 *
 * Optional body:
 * {
 *   "location": {
 *     "latitude": 12.921456,
 *     "longitude": 80.127845,
 *     "accuracy_meters": 10,
 *     "is_mocked": false
 *   }
 * }
 */
const checkOut = asyncHandler(async (req, res) => {
  const data = await attendanceService.checkOut({
    employeeId: req.auth.employeeId,
    body: req.body || {},
  });

  return sendSuccess(res, {
    statusCode: 200,
    message: 'Check-out successful',
    data,
  });
});

/**
 * POST /api/v1/attendance/breaks/start
 */
const startBreak = asyncHandler(
  async (req, res) => {
    const data =
      await attendanceService.startBreak({
        employeeId: req.auth.employeeId,
      });

    return sendSuccess(res, {
      statusCode: 200,
      message: 'Break started successfully',
      data,
    });
  },
);

/**
 * POST /api/v1/attendance/breaks/end
 */
const endBreak = asyncHandler(async (req, res) => {
  const data = await attendanceService.endBreak({
    employeeId: req.auth.employeeId,
  });

  return sendSuccess(res, {
    statusCode: 200,
    message: 'Break ended successfully',
    data,
  });
});

module.exports = {
  getToday,
  checkIn,
  checkOut,
  startBreak,
  endBreak,
};