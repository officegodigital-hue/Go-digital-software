import 'package:employee_mobile/features/attendance/data/models/today_attendance_response.dart';
import 'package:employee_mobile/features/attendance/data/repositories/attendance_repository.dart';
import 'package:flutter/foundation.dart';

class AttendanceController extends ChangeNotifier {
  AttendanceController({
    AttendanceRepository? repository,
  }) : _repository =
            repository ?? AttendanceRepository();

  final AttendanceRepository _repository;

  TodayAttendanceResponse? _todayAttendance;

  bool _isLoading = false;
  bool _isActionLoading = false;

  String? _errorMessage;
  String? _successMessage;

  // ---------------------------------------------------------------------------
  // Main response getters
  // ---------------------------------------------------------------------------

  TodayAttendanceResponse? get todayAttendance {
    return _todayAttendance;
  }

  TodayAttendanceData? get todayData {
    return _todayAttendance?.data;
  }

  TodayAttendanceRecord? get attendance {
    return todayData?.attendance;
  }

  TodayEmployee? get employee {
    return todayData?.employee;
  }

  TodayShift? get shift {
    return todayData?.shift;
  }

  TodayAttendanceSummary? get summary {
    return todayData?.summary;
  }

  TodayBreakRecord? get currentBreak {
    return todayData?.currentBreak;
  }

  // ---------------------------------------------------------------------------
  // Loading and message getters
  // ---------------------------------------------------------------------------

  bool get isLoading {
    return _isLoading;
  }

  bool get isAttendanceLoading {
    return _isLoading;
  }

  bool get isActionLoading {
    return _isActionLoading;
  }

  bool get isBusy {
    return _isLoading || _isActionLoading;
  }

  bool get hasTodayData {
    return _todayAttendance != null;
  }

  String? get errorMessage {
    return _errorMessage;
  }

  String? get successMessage {
    return _successMessage;
  }

  // ---------------------------------------------------------------------------
  // Attendance time getters
  // ---------------------------------------------------------------------------

  String? get checkInTime {
    return attendance?.checkInTime;
  }

  String? get checkOutTime {
    return attendance?.checkOutTime;
  }

  String? get breakStartTime {
    return currentBreak?.startTime;
  }

  String? get breakEndTime {
    return currentBreak?.endTime;
  }

  // ---------------------------------------------------------------------------
  // Attendance state getters
  // ---------------------------------------------------------------------------

  bool get hasCheckedIn {
    return todayData?.hasCheckedIn ?? false;
  }

  bool get isCheckedIn {
    return hasCheckedIn;
  }

  bool get hasCheckedOut {
    return todayData?.hasCheckedOut ?? false;
  }

  bool get isCheckedOut {
    return hasCheckedOut;
  }

  bool get isOnBreak {
    return todayData?.isOnBreak ?? false;
  }

  bool get onBreak {
    return isOnBreak;
  }

  bool get canCheckIn {
    return todayData?.canCheckIn ??
        (!hasCheckedIn && !hasCheckedOut);
  }

  bool get canStartBreak {
    return todayData?.canStartBreak ??
        (hasCheckedIn &&
            !hasCheckedOut &&
            !isOnBreak);
  }

  bool get canEndBreak {
    return todayData?.canEndBreak ??
        (hasCheckedIn &&
            !hasCheckedOut &&
            isOnBreak);
  }

  bool get canCheckOut {
    return todayData?.canCheckOut ??
        (hasCheckedIn &&
            !hasCheckedOut &&
            !isOnBreak);
  }

  // ---------------------------------------------------------------------------
  // Attendance summary getters
  // ---------------------------------------------------------------------------

  int get workedMinutes {
    return summary?.workedMinutes ??
        attendance?.workedMinutes ??
        0;
  }

  int get breakMinutes {
    return summary?.breakMinutes ??
        attendance?.breakMinutes ??
        0;
  }

  int get overtimeMinutes {
    return summary?.overtimeMinutes ??
        attendance?.overtimeMinutes ??
        0;
  }

  String get workingDurationLabel {
    return _formatMinutes(workedMinutes);
  }

  String get totalWorkingTimeLabel {
    return workingDurationLabel;
  }

  String get breakDurationLabel {
    return _formatMinutes(breakMinutes);
  }

  String get totalBreakTimeLabel {
    return breakDurationLabel;
  }

  String get overtimeLabel {
    return _formatMinutes(overtimeMinutes);
  }

  int get overtime {
    return overtimeMinutes;
  }

  // ---------------------------------------------------------------------------
  // Attendance status getters
  // ---------------------------------------------------------------------------

  String get status {
    return todayData?.status ?? 'not_checked_in';
  }

  String get statusLabel {
    return todayData?.statusLabel ??
        'Not Checked In';
  }

  // ---------------------------------------------------------------------------
  // Employee and shift getters
  // ---------------------------------------------------------------------------

  String get employeeName {
    return employee?.name ?? '';
  }

  String get employeeCode {
    return employee?.employeeCode ?? '';
  }

  String get departmentName {
    return employee?.departmentName ?? '';
  }

  String get designationName {
    return employee?.designationName ?? '';
  }

  String get branchName {
    return employee?.branchName ?? '';
  }

  String get shiftName {
    return shift?.name ?? '';
  }

  String? get shiftStartTime {
    return shift?.startTime;
  }

  String? get shiftEndTime {
    return shift?.endTime;
  }

  // ---------------------------------------------------------------------------
  // Initial loading
  // ---------------------------------------------------------------------------

  Future<void> initialize() async {
    await loadTodayAttendance();
  }

  Future<void> loadToday() async {
    await loadTodayAttendance();
  }

  Future<void> refresh() async {
    await loadTodayAttendance();
  }

  Future<void> loadTodayAttendance() async {
    if (_isLoading) {
      return;
    }

    _isLoading = true;
    _errorMessage = null;

    notifyListeners();

    try {
      final response =
          await _repository.getTodayAttendance();

      _todayAttendance = response;

      if (!response.success) {
        _errorMessage = response.message.isEmpty
            ? 'Unable to load attendance.'
            : response.message;
      }
    } on AttendanceRepositoryException catch (error) {
      _errorMessage = error.message;
    } catch (error) {
      _errorMessage =
          'Unable to load attendance: $error';
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // ---------------------------------------------------------------------------
  // Check In
  // ---------------------------------------------------------------------------

  Future<TodayAttendanceResponse?> checkIn({
    double? latitude,
    double? longitude,
    String? address,
  }) async {
    return _performAction(
      action: () {
        return _repository.checkIn(
          latitude: latitude,
          longitude: longitude,
          address: address,
        );
      },
      defaultSuccessMessage:
          'Checked in successfully.',
    );
  }

  Future<TodayAttendanceResponse?>
      submitCheckIn({
    double? latitude,
    double? longitude,
    String? address,
  }) async {
    return checkIn(
      latitude: latitude,
      longitude: longitude,
      address: address,
    );
  }

  // ---------------------------------------------------------------------------
  // Start Break
  // ---------------------------------------------------------------------------

  Future<TodayAttendanceResponse?>
      startBreak() async {
    return _performAction(
      action: _repository.startBreak,
      defaultSuccessMessage:
          'Break started successfully.',
    );
  }

  Future<TodayAttendanceResponse?>
      beginBreak() async {
    return startBreak();
  }

  // ---------------------------------------------------------------------------
  // End Break
  // ---------------------------------------------------------------------------

  Future<TodayAttendanceResponse?>
      endBreak() async {
    return _performAction(
      action: _repository.endBreak,
      defaultSuccessMessage:
          'Break ended successfully.',
    );
  }

  Future<TodayAttendanceResponse?>
      finishBreak() async {
    return endBreak();
  }

  // ---------------------------------------------------------------------------
  // Check Out
  // ---------------------------------------------------------------------------

  Future<TodayAttendanceResponse?> checkOut({
    double? latitude,
    double? longitude,
    String? address,
  }) async {
    return _performAction(
      action: () {
        return _repository.checkOut(
          latitude: latitude,
          longitude: longitude,
          address: address,
        );
      },
      defaultSuccessMessage:
          'Checked out successfully.',
    );
  }

  Future<TodayAttendanceResponse?>
      submitCheckOut({
    double? latitude,
    double? longitude,
    String? address,
  }) async {
    return checkOut(
      latitude: latitude,
      longitude: longitude,
      address: address,
    );
  }

  // ---------------------------------------------------------------------------
  // Shared action handler
  // ---------------------------------------------------------------------------

  Future<TodayAttendanceResponse?>
      _performAction({
    required Future<TodayAttendanceResponse>
        Function() action,
    required String defaultSuccessMessage,
  }) async {
    if (_isActionLoading) {
      return null;
    }

    _isActionLoading = true;
    _errorMessage = null;
    _successMessage = null;

    notifyListeners();

    try {
      final response = await action();

      _todayAttendance = response;

      if (!response.success) {
        _errorMessage = response.message.isEmpty
            ? 'Attendance action failed.'
            : response.message;

        return null;
      }

      _successMessage =
          response.message.trim().isEmpty
              ? defaultSuccessMessage
              : response.message.trim();

      return response;
    } on AttendanceRepositoryException catch (error) {
      _errorMessage = error.message;

      return null;
    } catch (error) {
      _errorMessage =
          'Attendance action failed: $error';

      return null;
    } finally {
      _isActionLoading = false;
      notifyListeners();
    }
  }

  // ---------------------------------------------------------------------------
  // Messages
  // ---------------------------------------------------------------------------

  void clearErrorMessage() {
    if (_errorMessage == null) {
      return;
    }

    _errorMessage = null;
    notifyListeners();
  }

  void clearSuccessMessage() {
    if (_successMessage == null) {
      return;
    }

    _successMessage = null;
    notifyListeners();
  }

  void clearMessages() {
    final hasMessage =
        _errorMessage != null ||
            _successMessage != null;

    if (!hasMessage) {
      return;
    }

    _errorMessage = null;
    _successMessage = null;

    notifyListeners();
  }

  // ---------------------------------------------------------------------------
  // Formatting
  // ---------------------------------------------------------------------------

  String formatTime(
    String? value,
  ) {
    if (value == null ||
        value.trim().isEmpty ||
        value.trim().toLowerCase() == 'null') {
      return '-- : --';
    }

    final text = value.trim();

    DateTime? parsedDate =
        DateTime.tryParse(text);

    if (parsedDate != null) {
      parsedDate = parsedDate.toLocal();

      return _formatDateTimeClock(
        parsedDate,
      );
    }

    final timeMatch = RegExp(
      r'^(\d{1,2}):(\d{2})(?::(\d{2}))?$',
    ).firstMatch(text);

    if (timeMatch != null) {
      final hour =
          int.parse(timeMatch.group(1)!);

      final minute = timeMatch.group(2)!;

      final displayHour =
          hour % 12 == 0 ? 12 : hour % 12;

      final period =
          hour >= 12 ? 'PM' : 'AM';

      return '$displayHour:$minute $period';
    }

    return text;
  }

  String formatCheckInTime() {
    return formatTime(checkInTime);
  }

  String formatCheckOutTime() {
    return formatTime(checkOutTime);
  }

  String _formatDateTimeClock(
    DateTime value,
  ) {
    final hour = value.hour % 12 == 0
        ? 12
        : value.hour % 12;

    final minute = value.minute
        .toString()
        .padLeft(2, '0');

    final period =
        value.hour >= 12 ? 'PM' : 'AM';

    return '$hour:$minute $period';
  }

  String _formatMinutes(
    int totalMinutes,
  ) {
    if (totalMinutes <= 0) {
      return '0m';
    }

    final hours = totalMinutes ~/ 60;
    final minutes = totalMinutes % 60;

    if (hours == 0) {
      return '${minutes}m';
    }

    if (minutes == 0) {
      return '${hours}h';
    }

    return '${hours}h ${minutes}m';
  }
}