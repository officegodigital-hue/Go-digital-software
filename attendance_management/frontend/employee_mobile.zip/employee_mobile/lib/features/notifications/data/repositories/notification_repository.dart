import 'package:dio/dio.dart';
import 'package:employee_mobile/core/network/api_client.dart';
import 'package:employee_mobile/features/notifications/data/models/notification_response.dart';

class NotificationRepository {
  NotificationRepository({Dio? dio}) : _dio = dio ?? ApiClient.instance.dio;

  final Dio _dio;

  Future<NotificationListResponse> getNotifications({
    bool unreadOnly = false,
  }) async {
    try {
      final response = await _getFirstAvailable(
        const <String>[
          '/notifications',
          '/notifications/my',
          '/notifications/list',
          '/employee/notifications',
        ],
        queryParameters: <String, dynamic>{if (unreadOnly) 'unread_only': true},
      );

      final json = _toMap(response.data);

      if (json == null) {
        throw const NotificationRepositoryException(
          'Invalid notification response received.',
        );
      }

      _validateResponse(json);

      return NotificationListResponse.fromJson(json);
    } on DioException catch (error) {
      throw NotificationRepositoryException(
        _extractDioErrorMessage(error),
        statusCode: error.response?.statusCode,
      );
    } on NotificationRepositoryException {
      rethrow;
    } catch (error) {
      throw NotificationRepositoryException(
        'Unable to load notifications: $error',
      );
    }
  }

  Future<String> markAsRead(int notificationId) async {
    try {
      final response = await _writeFirstAvailable(
        methods: const <String>['PATCH', 'POST', 'PUT'],
        endpoints: <String>[
          '/notifications/$notificationId/read',
          '/notifications/read/$notificationId',
          '/employee/notifications/$notificationId/read',
        ],
        data: const <String, dynamic>{'is_read': true},
      );

      final json = _toMap(response.data);

      if (json != null) {
        _validateResponse(json);
      }

      return _extractResponseMessage(response.data) ??
          'Notification marked as read.';
    } on DioException catch (error) {
      throw NotificationRepositoryException(
        _extractDioErrorMessage(error),
        statusCode: error.response?.statusCode,
      );
    } on NotificationRepositoryException {
      rethrow;
    } catch (error) {
      throw NotificationRepositoryException(
        'Unable to mark notification as read: $error',
      );
    }
  }

  Future<String> markAllAsRead() async {
    try {
      final response = await _writeFirstAvailable(
        methods: const <String>['PATCH', 'POST', 'PUT'],
        endpoints: const <String>[
          '/notifications/read-all',
          '/notifications/mark-all-read',
          '/notifications/all/read',
          '/employee/notifications/read-all',
        ],
        data: const <String, dynamic>{'is_read': true},
      );

      final json = _toMap(response.data);

      if (json != null) {
        _validateResponse(json);
      }

      return _extractResponseMessage(response.data) ??
          'All notifications marked as read.';
    } on DioException catch (error) {
      throw NotificationRepositoryException(
        _extractDioErrorMessage(error),
        statusCode: error.response?.statusCode,
      );
    } on NotificationRepositoryException {
      rethrow;
    } catch (error) {
      throw NotificationRepositoryException(
        'Unable to mark all notifications as read: $error',
      );
    }
  }

  Future<String> deleteNotification(int notificationId) async {
    try {
      final response = await _writeFirstAvailable(
        methods: const <String>['DELETE'],
        endpoints: <String>[
          '/notifications/$notificationId',
          '/notifications/delete/$notificationId',
          '/employee/notifications/$notificationId',
        ],
      );

      final json = _toMap(response.data);

      if (json != null) {
        _validateResponse(json);
      }

      return _extractResponseMessage(response.data) ??
          'Notification deleted successfully.';
    } on DioException catch (error) {
      throw NotificationRepositoryException(
        _extractDioErrorMessage(error),
        statusCode: error.response?.statusCode,
      );
    } on NotificationRepositoryException {
      rethrow;
    } catch (error) {
      throw NotificationRepositoryException(
        'Unable to delete notification: $error',
      );
    }
  }

  Future<int> getUnreadCount() async {
    try {
      final response = await _getFirstAvailable(const <String>[
        '/notifications/unread-count',
        '/notifications/count/unread',
        '/employee/notifications/unread-count',
      ]);

      final json = _toMap(response.data);

      if (json == null) {
        final notificationResponse = await getNotifications();

        return notificationResponse.unreadCount;
      }

      _validateResponse(json);

      final count = _readInt(json, const <String>[
        'unread_count',
        'unreadCount',
        'count',
        'total_unread',
        'totalUnread',
      ]);

      if (count != null) {
        return count;
      }

      final notificationResponse = await getNotifications();

      return notificationResponse.unreadCount;
    } on DioException catch (error) {
      final statusCode = error.response?.statusCode;

      if (statusCode == 404 || statusCode == 405) {
        final notificationResponse = await getNotifications();

        return notificationResponse.unreadCount;
      }

      throw NotificationRepositoryException(
        _extractDioErrorMessage(error),
        statusCode: statusCode,
      );
    } on NotificationRepositoryException {
      rethrow;
    } catch (error) {
      throw NotificationRepositoryException(
        'Unable to load unread notification count: $error',
      );
    }
  }

  Future<Response<dynamic>> _getFirstAvailable(
    List<String> endpoints, {
    Map<String, dynamic>? queryParameters,
  }) async {
    DioException? lastError;

    for (final endpoint in endpoints) {
      try {
        return await _dio.get<dynamic>(
          endpoint,
          queryParameters: queryParameters,
        );
      } on DioException catch (error) {
        lastError = error;

        final statusCode = error.response?.statusCode;

        if (statusCode == 404 || statusCode == 405) {
          continue;
        }

        rethrow;
      }
    }

    if (lastError != null) {
      throw lastError;
    }

    throw const NotificationRepositoryException(
      'Notification API endpoint is unavailable.',
    );
  }

  Future<Response<dynamic>> _writeFirstAvailable({
    required List<String> methods,
    required List<String> endpoints,
    Object? data,
  }) async {
    DioException? lastError;

    for (final method in methods) {
      for (final endpoint in endpoints) {
        try {
          return await _dio.request<dynamic>(
            endpoint,
            data: data,
            options: Options(method: method),
          );
        } on DioException catch (error) {
          lastError = error;

          final statusCode = error.response?.statusCode;

          if (statusCode == 404 || statusCode == 405) {
            continue;
          }

          rethrow;
        }
      }
    }

    if (lastError != null) {
      throw lastError;
    }

    throw const NotificationRepositoryException(
      'Notification action endpoint is unavailable.',
    );
  }

  void _validateResponse(Map<String, dynamic> json) {
    final success = json['success'];

    final failed =
        success == false ||
        success == 0 ||
        success?.toString().trim().toLowerCase() == 'false';

    if (!failed) {
      return;
    }

    throw NotificationRepositoryException(
      _extractResponseMessage(json) ?? 'Notification request failed.',
    );
  }

  Map<String, dynamic>? _toMap(dynamic value) {
    if (value is Map<String, dynamic>) {
      return value;
    }

    if (value is Map) {
      return value.map<String, dynamic>((dynamic key, dynamic item) {
        return MapEntry<String, dynamic>(key.toString(), item);
      });
    }

    return null;
  }

  String? _extractResponseMessage(dynamic source) {
    final json = _toMap(source);

    if (json == null) {
      return null;
    }

    final value =
        json['message'] ?? json['error'] ?? json['details'] ?? json['msg'];

    if (value == null || value is Map || value is List) {
      return null;
    }

    final text = value.toString().trim();

    return text.isEmpty ? null : text;
  }

  String _extractDioErrorMessage(DioException error) {
    final responseMessage = _extractResponseMessage(error.response?.data);

    if (responseMessage != null && responseMessage.isNotEmpty) {
      return responseMessage;
    }

    switch (error.type) {
      case DioExceptionType.connectionTimeout:
      case DioExceptionType.sendTimeout:
      case DioExceptionType.receiveTimeout:
        return 'Notification request timed out.';

      case DioExceptionType.connectionError:
        return 'Unable to connect to the notification server.';

      case DioExceptionType.cancel:
        return 'Notification request was cancelled.';

      case DioExceptionType.badResponse:
        return 'Notification request failed with status '
            '${error.response?.statusCode ?? 'unknown'}.';

      default:
        return error.message ?? 'Unable to complete the notification request.';
    }
  }

  int? _readInt(dynamic source, List<String> keys) {
    final value = _findValue(source, keys);

    if (value is int) {
      return value;
    }

    if (value is num) {
      return value.round();
    }

    return int.tryParse(value?.toString() ?? '');
  }

  dynamic _findValue(dynamic source, List<String> keys) {
    final normalizedKeys = keys.map(_normalizeKey).toSet();

    return _findValueRecursive(source, normalizedKeys, <int>{});
  }

  dynamic _findValueRecursive(
    dynamic source,
    Set<String> keys,
    Set<int> visited,
  ) {
    if (source == null) {
      return null;
    }

    if (source is Map) {
      final identity = identityHashCode(source);

      if (visited.contains(identity)) {
        return null;
      }

      visited.add(identity);

      for (final entry in source.entries) {
        final normalizedKey = _normalizeKey(entry.key.toString());

        if (keys.contains(normalizedKey)) {
          return entry.value;
        }
      }

      for (final value in source.values) {
        final foundValue = _findValueRecursive(value, keys, visited);

        if (foundValue != null) {
          return foundValue;
        }
      }
    }

    if (source is List) {
      final identity = identityHashCode(source);

      if (visited.contains(identity)) {
        return null;
      }

      visited.add(identity);

      for (final value in source) {
        final foundValue = _findValueRecursive(value, keys, visited);

        if (foundValue != null) {
          return foundValue;
        }
      }
    }

    return null;
  }

  String _normalizeKey(String value) {
    return value.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');
  }
}

class NotificationRepositoryException implements Exception {
  const NotificationRepositoryException(this.message, {this.statusCode});

  final String message;
  final int? statusCode;

  @override
  String toString() {
    return message;
  }
}
