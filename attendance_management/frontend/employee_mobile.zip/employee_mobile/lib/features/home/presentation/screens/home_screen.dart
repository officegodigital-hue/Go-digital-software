import 'package:employee_mobile/features/attendance/presentation/controllers/attendance_controller.dart';
import 'package:employee_mobile/features/attendance/presentation/screens/attendance_history_screen.dart';
import 'package:employee_mobile/features/leave/presentation/controllers/leave_controller.dart';
import 'package:employee_mobile/features/leave/presentation/screens/leave_dashboard_screen.dart';
import 'package:employee_mobile/features/notifications/presentation/screens/notification_screen.dart';
import 'package:employee_mobile/features/profile/presentation/screens/profile_screen.dart';
import 'package:flutter/material.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({required this.employeeName, super.key});

  final String employeeName;

  @override
  State<HomeScreen> createState() {
    return _HomeScreenState();
  }
}

class _HomeScreenState extends State<HomeScreen> {
  static const Color _primaryBlue = Color(0xFF075ECF);
  static const Color _darkBlue = Color(0xFF07459A);
  static const Color _pageBackground = Color(0xFFFDFDFD);
  static const Color _lightBorder = Color(0xFFE8ECF3);
  static const Color _mutedText = Color(0xFF667085);

  late final AttendanceController _attendanceController;
  late final LeaveController _leaveController;

  bool _isActionLoading = false;
  int _selectedNavigationIndex = 0;

  @override
  void initState() {
    super.initState();

    _attendanceController = AttendanceController();
    _leaveController = LeaveController();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _loadTodayAttendance();
    });
  }

  @override
  void dispose() {
    _attendanceController.dispose();
    _leaveController.dispose();
    super.dispose();
  }

  dynamic get _attendance {
    return _attendanceController;
  }

  String get _displayName {
    final name = widget.employeeName.trim();
    return name.isEmpty ? 'Employee' : name;
  }

  String get _checkInTime {
    return _formatTime(
      _readFirst(<dynamic Function()>[
        () => _attendance.checkInTime,
        () => _attendance.attendance?.checkInTime,
        () => _attendance.attendance?.check_in_time,
        () => _attendance.todayData?.attendance?.checkInTime,
        () => _attendance.todayData?.attendance?.check_in_time,
        () => _attendance.todayAttendance?.attendance?.checkInTime,
        () => _attendance.todayAttendance?.attendance?.check_in_time,
        () => _attendance.todayAttendance?.data?.attendance?.checkInTime,
        () => _attendance.todayAttendance?.data?.attendance?.check_in_time,
      ]),
    );
  }

  String get _checkOutTime {
    return _formatTime(
      _readFirst(<dynamic Function()>[
        () => _attendance.checkOutTime,
        () => _attendance.attendance?.checkOutTime,
        () => _attendance.attendance?.check_out_time,
        () => _attendance.todayData?.attendance?.checkOutTime,
        () => _attendance.todayData?.attendance?.check_out_time,
        () => _attendance.todayAttendance?.attendance?.checkOutTime,
        () => _attendance.todayAttendance?.attendance?.check_out_time,
        () => _attendance.todayAttendance?.data?.attendance?.checkOutTime,
        () => _attendance.todayAttendance?.data?.attendance?.check_out_time,
      ]),
    );
  }

  String get _workingHours {
    return _readText(<dynamic Function()>[
      () => _attendance.workingDurationLabel,
      () => _attendance.totalWorkingTimeLabel,
      () => _attendance.attendance?.workingDurationLabel,
      () => _attendance.todayData?.summary?.workingDuration,
      () => _attendance.todayAttendance?.data?.summary?.workingDuration,
      () => _attendance.todayAttendance?.data?.summary?.workingHours,
    ], fallback: '--');
  }

  String get _breakDuration {
    return _readText(<dynamic Function()>[
      () => _attendance.breakDurationLabel,
      () => _attendance.totalBreakTimeLabel,
      () => _attendance.attendance?.breakDurationLabel,
      () => _attendance.todayData?.summary?.breakDuration,
      () => _attendance.todayAttendance?.data?.summary?.breakDuration,
    ], fallback: '--');
  }

  String get _overtime {
    return _readText(<dynamic Function()>[
      () => _attendance.overtimeLabel,
      () => _attendance.overtime,
      () => _attendance.todayData?.summary?.overtime,
      () => _attendance.todayAttendance?.data?.summary?.overtime,
    ], fallback: '--');
  }

  bool get _hasCheckedIn {
    if (_checkInTime != '--') {
      return true;
    }

    return _readBool(<dynamic Function()>[
      () => _attendance.hasCheckedIn,
      () => _attendance.isCheckedIn,
      () => _attendance.todayData?.hasCheckedIn,
      () => _attendance.todayAttendance?.data?.hasCheckedIn,
    ], fallback: false);
  }

  bool get _hasCheckedOut {
    if (_checkOutTime != '--') {
      return true;
    }

    return _readBool(<dynamic Function()>[
      () => _attendance.hasCheckedOut,
      () => _attendance.isCheckedOut,
      () => _attendance.todayData?.hasCheckedOut,
      () => _attendance.todayAttendance?.data?.hasCheckedOut,
    ], fallback: false);
  }

  bool get _isOnBreak {
    return _readBool(<dynamic Function()>[
      () => _attendance.isOnBreak,
      () => _attendance.onBreak,
      () => _attendance.todayData?.isOnBreak,
      () => _attendance.todayAttendance?.data?.isOnBreak,
      () => _attendance.currentBreak != null,
      () => _attendance.todayData?.currentBreak != null,
      () => _attendance.todayAttendance?.data?.currentBreak != null,
    ], fallback: false);
  }

  String get _status {
    final rawStatus = _readText(<dynamic Function()>[
      () => _attendance.status,
      () => _attendance.statusLabel,
      () => _attendance.attendance?.status,
      () => _attendance.todayData?.attendance?.status,
      () => _attendance.todayAttendance?.data?.attendance?.status,
    ], fallback: '').toLowerCase();

    if (_hasCheckedOut) {
      return 'Completed';
    }

    if (_isOnBreak) {
      return 'On Break';
    }

    switch (rawStatus) {
      case 'present':
        return 'Present';
      case 'late':
        return 'Late';
      case 'half_day':
        return 'Half Day';
      case 'absent':
        return 'Absent';
      case 'leave':
        return 'On Leave';
      case 'checked_in':
      case 'working':
        return 'Working';
      case 'checked_out':
      case 'completed':
        return 'Completed';
      case 'on_break':
        return 'On Break';
    }

    return _hasCheckedIn ? 'Working' : '--';
  }

  bool get _canStartBreak {
    return _hasCheckedIn && !_hasCheckedOut && !_isOnBreak;
  }

  bool get _canEndBreak {
    return _hasCheckedIn && !_hasCheckedOut && _isOnBreak;
  }

  bool get _canCheckOut {
    return _hasCheckedIn && !_hasCheckedOut && !_isOnBreak;
  }

  String get _mainActionLabel {
    if (!_hasCheckedIn) {
      return 'CHECK IN';
    }

    if (_hasCheckedOut) {
      return 'COMPLETED';
    }

    if (_isOnBreak) {
      return 'END BREAK';
    }

    return 'CHECK OUT';
  }

  IconData get _mainActionIcon {
    if (!_hasCheckedIn) {
      return Icons.location_on_rounded;
    }

    if (_hasCheckedOut) {
      return Icons.check_circle_rounded;
    }

    if (_isOnBreak) {
      return Icons.restaurant_rounded;
    }

    return Icons.logout_rounded;
  }

  Future<void> _loadTodayAttendance() async {
    final dynamic controller = _attendance;

    try {
      await _invokeFirstAvailable(<Future<void> Function()>[
        () async => controller.loadTodayAttendance(),
        () async => controller.loadToday(),
        () async => controller.initialize(),
      ]);
    } catch (_) {
      // The Home UI still renders if the controller uses another load method.
    }

    if (mounted) {
      setState(() {});
    }
  }

  Future<void> _performAttendanceAction(
    Future<void> Function() action,
    String successMessage,
  ) async {
    if (_isActionLoading) {
      return;
    }

    setState(() {
      _isActionLoading = true;
    });

    try {
      await action();
      await _loadTodayAttendance();

      if (!mounted) {
        return;
      }

      _showMessage(successMessage);
    } catch (error) {
      if (!mounted) {
        return;
      }

      _showMessage(error.toString(), isError: true);
    } finally {
      if (mounted) {
        setState(() {
          _isActionLoading = false;
        });
      }
    }
  }

  Future<void> _checkIn() async {
    final dynamic controller = _attendance;

    await _performAttendanceAction(() {
      return _invokeFirstAvailable(<Future<void> Function()>[
        () async => controller.checkIn(),
        () async => controller.submitCheckIn(),
      ]);
    }, 'Checked in successfully.');
  }

  Future<void> _startBreak() async {
    final dynamic controller = _attendance;

    await _performAttendanceAction(() {
      return _invokeFirstAvailable(<Future<void> Function()>[
        () async => controller.startBreak(),
        () async => controller.beginBreak(),
      ]);
    }, 'Break started successfully.');
  }

  Future<void> _endBreak() async {
    final dynamic controller = _attendance;

    await _performAttendanceAction(() {
      return _invokeFirstAvailable(<Future<void> Function()>[
        () async => controller.endBreak(),
        () async => controller.finishBreak(),
      ]);
    }, 'Break ended successfully.');
  }

  Future<void> _checkOut() async {
    final dynamic controller = _attendance;

    await _performAttendanceAction(() {
      return _invokeFirstAvailable(<Future<void> Function()>[
        () async => controller.checkOut(),
        () async => controller.submitCheckOut(),
      ]);
    }, 'Checked out successfully.');
  }

  Future<void> _handleMainAction() async {
    if (!_hasCheckedIn) {
      await _checkIn();
      return;
    }

    if (_hasCheckedOut) {
      return;
    }

    if (_isOnBreak) {
      await _endBreak();
      return;
    }

    await _checkOut();
  }

  Future<void> _openLeaveDashboard() async {
    await Navigator.of(context).push<void>(
      MaterialPageRoute<void>(
        builder: (context) {
          return LeaveDashboardScreen(controller: _leaveController);
        },
      ),
    );
  }

  Future<void> _openAttendanceHistory() async {
    await Navigator.of(context).push<void>(
      MaterialPageRoute<void>(
        builder: (BuildContext context) {
          return const AttendanceHistoryScreen();
        },
      ),
    );
  }

  Future<void> _openAlerts() async {
    await Navigator.of(context).push<void>(
      MaterialPageRoute<void>(
        builder: (BuildContext context) {
          return const NotificationScreen();
        },
      ),
    );
  }

  Future<void> _openProfile() async {
    await Navigator.of(context).push<void>(
      MaterialPageRoute<void>(
        builder: (BuildContext context) {
          return const ProfileScreen();
        },
      ),
    );
  }

  Future<void> _showLocation() async {
    _showMessage(
      'Location access will be connected with the attendance action.',
    );
  }

  Future<void> _onNavigationTapped(int index) async {
    if (index == 0) {
      setState(() {
        _selectedNavigationIndex = 0;
      });
      return;
    }

    setState(() {
      _selectedNavigationIndex = index;
    });

    if (index == 1) {
      await _openAttendanceHistory();
    } else if (index == 2) {
      await _openLeaveDashboard();
    } else if (index == 3) {
      await _openAlerts();
    } else if (index == 4) {
      await _openProfile();
    }

    if (!mounted) {
      return;
    }

    setState(() {
      _selectedNavigationIndex = 0;
    });
  }

  void _showMessage(String message, {bool isError = false}) {
    if (!mounted) {
      return;
    }

    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(message),
          backgroundColor: isError ? Theme.of(context).colorScheme.error : null,
        ),
      );
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _attendanceController,
      builder: (context, child) {
        return Scaffold(
          backgroundColor: _pageBackground,
          body: SafeArea(
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 430),
                child: RefreshIndicator(
                  onRefresh: _loadTodayAttendance,
                  child: ListView(
                    physics: const AlwaysScrollableScrollPhysics(),
                    padding: const EdgeInsets.fromLTRB(18, 14, 18, 24),
                    children: <Widget>[
                      _buildHeader(context),
                      const SizedBox(height: 22),
                      _buildAttendanceCard(context),
                      const SizedBox(height: 20),
                      _buildActionRow(context),
                      const SizedBox(height: 24),
                      _buildSummaryHeader(context),
                      const SizedBox(height: 12),
                      _buildSummaryCard(context),
                    ],
                  ),
                ),
              ),
            ),
          ),
          bottomNavigationBar: _buildBottomNavigation(),
        );
      },
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Row(
      children: <Widget>[
        Container(
          width: 43,
          height: 43,
          decoration: BoxDecoration(
            color: const Color(0xFFE9F0FF),
            shape: BoxShape.circle,
            border: Border.all(color: const Color(0xFFB7CCFA)),
          ),
          child: Center(
            child: Text(
              _initials(_displayName),
              style: const TextStyle(
                color: _primaryBlue,
                fontSize: 15,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ),
        const SizedBox(width: 11),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                '${_greeting()}, $_displayName 👋',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: _darkBlue,
                  fontSize: 17,
                  fontWeight: FontWeight.w800,
                  height: 1.1,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                _formatCurrentDate(),
                style: const TextStyle(
                  color: _mutedText,
                  fontSize: 10.5,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
        Stack(
          clipBehavior: Clip.none,
          children: <Widget>[
            IconButton(
              tooltip: 'Alerts',
              onPressed: _openAlerts,
              icon: const Icon(
                Icons.notifications_none_rounded,
                color: _primaryBlue,
                size: 23,
              ),
            ),
            Positioned(
              right: 10,
              top: 9,
              child: Container(
                width: 7,
                height: 7,
                decoration: const BoxDecoration(
                  color: Color(0xFFE53935),
                  shape: BoxShape.circle,
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildAttendanceCard(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: <Color>[Color(0xFF075BCF), Color(0xFF0A70E6)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(11),
        boxShadow: <BoxShadow>[
          BoxShadow(
            color: _primaryBlue.withValues(alpha: 0.24),
            blurRadius: 16,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        children: <Widget>[
          Row(
            children: <Widget>[
              Expanded(
                child: _AttendanceTimeColumn(
                  label: 'Check In',
                  value: _checkInTime,
                ),
              ),
              Container(
                width: 1,
                height: 44,
                color: Colors.white.withValues(alpha: 0.22),
              ),
              Expanded(
                child: _AttendanceTimeColumn(
                  label: 'Check Out',
                  value: _checkOutTime,
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          SizedBox(
            width: double.infinity,
            height: 47,
            child: FilledButton.icon(
              onPressed:
                  _isActionLoading ||
                      (_hasCheckedOut && _mainActionLabel == 'COMPLETED')
                  ? null
                  : _handleMainAction,
              style: FilledButton.styleFrom(
                backgroundColor: Colors.white,
                foregroundColor: _darkBlue,
                disabledBackgroundColor: Colors.white.withValues(alpha: 0.85),
                disabledForegroundColor: _darkBlue.withValues(alpha: 0.55),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(6),
                ),
              ),
              icon: _isActionLoading
                  ? const SizedBox(
                      width: 17,
                      height: 17,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : Icon(_mainActionIcon, size: 18),
              label: Text(
                _isActionLoading ? 'PLEASE WAIT' : _mainActionLabel,
                style: const TextStyle(
                  fontSize: 12.5,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 0.2,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionRow(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: <Widget>[
        _ActionItem(
          icon: Icons.local_cafe_outlined,
          label: 'Start\nBreak',
          iconColor: const Color(0xFFFFA41C),
          backgroundColor: const Color(0xFFFFF4E1),
          enabled: _canStartBreak && !_isActionLoading,
          onTap: _startBreak,
        ),
        _ActionItem(
          icon: Icons.restaurant_rounded,
          label: 'End\nBreak',
          iconColor: const Color(0xFF00A86B),
          backgroundColor: const Color(0xFFE4F8EF),
          enabled: _canEndBreak && !_isActionLoading,
          onTap: _endBreak,
        ),
        _ActionItem(
          icon: Icons.logout_rounded,
          label: 'Check\nOut',
          iconColor: const Color(0xFFFF5964),
          backgroundColor: const Color(0xFFFFEBED),
          enabled: _canCheckOut && !_isActionLoading,
          onTap: _checkOut,
        ),
        _ActionItem(
          icon: Icons.location_on_outlined,
          label: 'My\nLocation',
          iconColor: const Color(0xFF1A8CFF),
          backgroundColor: const Color(0xFFE8F3FF),
          enabled: true,
          onTap: _showLocation,
        ),
      ],
    );
  }

  Widget _buildSummaryHeader(BuildContext context) {
    return Row(
      children: <Widget>[
        const Expanded(
          child: Text(
            "Today's Summary",
            style: TextStyle(
              color: Color(0xFF132A55),
              fontSize: 14.5,
              fontWeight: FontWeight.w800,
            ),
          ),
        ),
        TextButton(
          onPressed: _openAttendanceHistory,
          style: TextButton.styleFrom(
            foregroundColor: _primaryBlue,
            padding: EdgeInsets.zero,
            minimumSize: const Size(0, 30),
            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
          ),
          child: const Text(
            'View History',
            style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700),
          ),
        ),
      ],
    );
  }

  Widget _buildSummaryCard(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(11),
        border: Border.all(color: _lightBorder),
      ),
      child: Column(
        children: <Widget>[
          _SummaryRow(
            icon: Icons.access_time_rounded,
            label: 'Working Hours',
            value: _workingHours,
          ),
          const Divider(height: 1, color: _lightBorder),
          _SummaryRow(
            icon: Icons.timer_outlined,
            label: 'Break Duration',
            value: _breakDuration,
          ),
          const Divider(height: 1, color: _lightBorder),
          _SummaryRow(
            icon: Icons.alarm_rounded,
            label: 'Overtime',
            value: _overtime,
          ),
          const Divider(height: 1, color: _lightBorder),
          _SummaryRow(
            icon: Icons.info_outline_rounded,
            label: 'Status',
            value: _status,
          ),
        ],
      ),
    );
  }

  Widget _buildBottomNavigation() {
    return BottomNavigationBar(
      currentIndex: _selectedNavigationIndex,
      onTap: _onNavigationTapped,
      type: BottomNavigationBarType.fixed,
      backgroundColor: Colors.white,
      elevation: 12,
      selectedItemColor: _primaryBlue,
      unselectedItemColor: const Color(0xFF4F5668),
      selectedFontSize: 10,
      unselectedFontSize: 10,
      selectedLabelStyle: const TextStyle(fontWeight: FontWeight.w700),
      unselectedLabelStyle: const TextStyle(fontWeight: FontWeight.w500),
      items: const <BottomNavigationBarItem>[
        BottomNavigationBarItem(
          icon: Icon(Icons.home_outlined),
          activeIcon: Icon(Icons.home_rounded),
          label: 'Home',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.calendar_month_outlined),
          activeIcon: Icon(Icons.calendar_month_rounded),
          label: 'Attendance',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.event_note_outlined),
          activeIcon: Icon(Icons.event_note_rounded),
          label: 'Leave',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.notifications_none_rounded),
          activeIcon: Icon(Icons.notifications_rounded),
          label: 'Alerts',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.person_outline_rounded),
          activeIcon: Icon(Icons.person_rounded),
          label: 'Profile',
        ),
      ],
    );
  }

  dynamic _readFirst(List<dynamic Function()> readers) {
    for (final reader in readers) {
      try {
        final value = reader();

        if (value != null) {
          return value;
        }
      } catch (_) {
        continue;
      }
    }

    return null;
  }

  String _readText(
    List<dynamic Function()> readers, {
    required String fallback,
  }) {
    final value = _readFirst(readers);

    if (value == null) {
      return fallback;
    }

    final text = value.toString().trim();

    if (text.isEmpty || text.toLowerCase() == 'null') {
      return fallback;
    }

    return text;
  }

  bool _readBool(List<dynamic Function()> readers, {required bool fallback}) {
    final value = _readFirst(readers);

    if (value is bool) {
      return value;
    }

    if (value is num) {
      return value != 0;
    }

    if (value != null) {
      final normalized = value.toString().toLowerCase();

      if (normalized == 'true' || normalized == '1') {
        return true;
      }

      if (normalized == 'false' || normalized == '0') {
        return false;
      }
    }

    return fallback;
  }

  Future<void> _invokeFirstAvailable(
    List<Future<void> Function()> methods,
  ) async {
    for (final method in methods) {
      try {
        await method();
        return;
      } on NoSuchMethodError {
        continue;
      }
    }

    throw StateError('Required attendance controller method is unavailable.');
  }

  String _formatTime(dynamic value) {
    if (value == null) {
      return '-- : --';
    }

    DateTime? parsedDate;

    if (value is DateTime) {
      parsedDate = value.toLocal();
    } else {
      final text = value.toString().trim();

      if (text.isEmpty || text.toLowerCase() == 'null') {
        return '-- : --';
      }

      parsedDate = DateTime.tryParse(text)?.toLocal();

      if (parsedDate == null) {
        final match = RegExp(
          r'^(\d{1,2}):(\d{2})(?::\d{2})?$',
        ).firstMatch(text);

        if (match == null) {
          return text;
        }

        final hour = int.parse(match.group(1)!);
        final minute = match.group(2)!;
        final displayHour = hour % 12 == 0 ? 12 : hour % 12;
        final period = hour >= 12 ? 'PM' : 'AM';

        return '$displayHour:$minute $period';
      }
    }

    final hour = parsedDate.hour % 12 == 0 ? 12 : parsedDate.hour % 12;
    final minute = parsedDate.minute.toString().padLeft(2, '0');
    final period = parsedDate.hour >= 12 ? 'PM' : 'AM';

    return '$hour:$minute $period';
  }

  String _greeting() {
    final hour = DateTime.now().hour;

    if (hour < 12) {
      return 'Good Morning';
    }

    if (hour < 17) {
      return 'Good Afternoon';
    }

    return 'Good Evening';
  }

  String _formatCurrentDate() {
    final value = DateTime.now();

    const weekdays = <String>[
      'Monday',
      'Tuesday',
      'Wednesday',
      'Thursday',
      'Friday',
      'Saturday',
      'Sunday',
    ];

    const months = <String>[
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December',
    ];

    return '${value.day} ${months[value.month - 1]} '
        '${value.year}, ${weekdays[value.weekday - 1]}';
  }

  String _initials(String value) {
    final words = value
        .trim()
        .split(RegExp(r'\s+'))
        .where((word) => word.isNotEmpty)
        .toList();

    if (words.isEmpty) {
      return 'E';
    }

    if (words.length == 1) {
      return words.first.substring(0, 1).toUpperCase();
    }

    return '${words.first.substring(0, 1)}'
            '${words.last.substring(0, 1)}'
        .toUpperCase();
  }
}

class _AttendanceTimeColumn extends StatelessWidget {
  const _AttendanceTimeColumn({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        Text(
          label,
          style: TextStyle(
            color: Colors.white.withValues(alpha: 0.74),
            fontSize: 11,
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          value,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 22,
            fontWeight: FontWeight.w700,
            letterSpacing: 0.4,
          ),
        ),
      ],
    );
  }
}

class _ActionItem extends StatelessWidget {
  const _ActionItem({
    required this.icon,
    required this.label,
    required this.iconColor,
    required this.backgroundColor,
    required this.enabled,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final Color iconColor;
  final Color backgroundColor;
  final bool enabled;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Opacity(
      opacity: enabled ? 1 : 0.45,
      child: InkWell(
        onTap: enabled ? onTap : null,
        borderRadius: BorderRadius.circular(10),
        child: SizedBox(
          width: 64,
          child: Column(
            children: <Widget>[
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: backgroundColor,
                  borderRadius: BorderRadius.circular(9),
                ),
                child: Icon(icon, color: iconColor, size: 21),
              ),
              const SizedBox(height: 7),
              Text(
                label,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Color(0xFF222A3A),
                  fontSize: 10.5,
                  height: 1.15,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SummaryRow extends StatelessWidget {
  const _SummaryRow({
    required this.icon,
    required this.label,
    required this.value,
  });

  final IconData icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 14),
      child: Row(
        children: <Widget>[
          Container(
            width: 31,
            height: 31,
            decoration: const BoxDecoration(
              color: Color(0xFFEAF1FF),
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: _HomeScreenState._primaryBlue, size: 17),
          ),
          const SizedBox(width: 11),
          Expanded(
            child: Text(
              label,
              style: const TextStyle(
                color: Color(0xFF545D6E),
                fontSize: 11.5,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          Text(
            value,
            style: const TextStyle(
              color: Color(0xFF132A55),
              fontSize: 11.5,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}
