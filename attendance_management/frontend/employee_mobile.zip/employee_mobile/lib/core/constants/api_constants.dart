class ApiConstants {
  const ApiConstants._();

  static const String baseUrl =
      'http://localhost:3000/api/v1';

  static const Duration connectTimeout =
      Duration(seconds: 20);

  static const Duration receiveTimeout =
      Duration(seconds: 20);

  static const Duration sendTimeout =
      Duration(seconds: 20);

  // Authentication
  static const String login = '/auth/login';
  static const String currentUser = '/auth/me';

  // Today's attendance
  static const String attendanceToday =
      '/attendance/today';

  static const String attendanceCheckIn =
      '/attendance/check-in';

  static const String attendanceCheckOut =
      '/attendance/check-out';

  static const String attendanceStartBreak =
      '/attendance/breaks/start';

  static const String attendanceEndBreak =
      '/attendance/breaks/end';

  // Attendance history
  static const String attendanceHistory =
      '/attendance/history';


 static const String leaveDashboard =
    '/leaves/dashboard';

static const String leaveHistory =
    '/leaves/history';

static const String leaveApply =
    '/leaves';

static String leaveCancel(
  int leaveRequestId,
) {
  return '/leaves/$leaveRequestId/cancel';
}
     
}

